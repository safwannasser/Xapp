package com.example.xapp;
import java.util.ArrayList;

public class Teachername {
    String name;
    ArrayList<String> list;
}
