package com.example.xapp;

import java.sql.Statement;

public class Messages {
       public String timestamp="";
       public String msgtxt="";
       public  String sender="";
}