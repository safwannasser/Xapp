package com.example.xapp;

import java.util.ArrayList;

public class Studentname {
    String name;
    int rank;
    ArrayList<String> list;
}
